/*
=====================================================================
EXECUTION OS — PROJECT CONSTITUTION
=====================================================================
Status: Accepted content, Proposed overall (see 00_Project_State.js)
Version: derived from Execution OS Architecture Design v0.8
Date: 2026-07-25 (this extraction: 2026-07-26)
Code status (updated 2026-10-31): Slice 0 — Foundation in progress.
  Seven runtime files built and sandbox-tested (154/154), none verified
  in real GAS, plus a GAS-native verification gate for 15_TruthEngine.js
  (90_UnitTests.js; 65/65 sandbox tests of the gate itself, not yet run
  in Apps Script) — 00_Project_State.js is the authoritative record.
  (This line read "ZERO — this project has no implementation yet": true
  when written 2026-07-25/26, stale since the first checkpoint
  2026-09-12/14; it read "Six ... (100/100)" until 15_TruthEngine.js,
  2026-10-26; the gate was added 2026-10-31.)
  Updated 2026-11-03: the numbers and the "none verified in real GAS"
  above are superseded. The gate ran once in real Apps Script on
  2026-11-03 and found two defects in 15_TruthEngine.js, which was then
  changed (P10, P11; PROPOSED, ADR-022). The seven runtime suites are now
  167/167 (15_TruthEngine.js: 67); the gate's own suite has 26 failing
  checks against the changed engine because its fake platform is out of
  date (00_Project_State.js item 18). The new code has been run only in
  the Node sandbox. 00_Project_State.js is the authoritative record.
Governance updated 2026-11-01 (no code changed): a WORKING RULES block
  (ADR-019, ADR-020, both Accepted) and a PROPOSED PRACTICES block
  (ADR-021 to ADR-024, not ratified by the owner) were added below. The
  Code status above is unchanged: nothing was built or run on
  2026-11-01.
Depends On: UEF >= 1.12, Blueprint >= 1.2 (see ADR-014 in 00_ADR_Log.js).
  UEF v1.12's full primary text was read directly 2026-09-12 (Stable,
  2026-08-16) — this line previously read ">= 1.3" based on the only
  version text this project had actually read; that has now been
  verified and updated, not merely re-reported from ecosystem memory.
  Blueprint's version is unchanged (UEF v1.12 states Blueprint is
  "Stable as of v1.2").
=====================================================================

SYSTEM IDENTITY
---------------------------------------------------------------------
Execution OS is NOT a Domain OS.

It is an Execution Coordinator: a layer that runs above every Domain
OS, responsible for "life execution" itself (Vision -> Goal -> action
-> review), and never for any single Domain's business data.

One-line positioning:
  Execution OS is the Personal AI Ecosystem's Execution Coordination
  Layer, responsible for aggregation, planning, sequencing, review,
  and cross-Domain coordination, but never the owner of any Business
  State.

Constitution boundary declaration (the single most important rule
in this document):
  Execution OS owns no Business Data; it owns only Execution Data,
  related to each Domain solely through Reference.

As long as this rule holds, adding any future Domain (Health OS,
Content OS, or otherwise) never requires re-architecting Execution OS.

OWNS
---------------------------------------------------------------------
  Intent layer:      Vision, Goal
  Execution layer:    Execution Project, Planning
  View layer:         Today View, Week View, Dashboard
  Governance layer:    Review, Waiting, Execution Event
  Connection layer:    Execution Reference (a pointer, never the data
                        itself)

NEVER OWNS
---------------------------------------------------------------------
  Business Task / Business Project / Business Timeline / Business
  Event — these always belong to whichever Domain produced them
  (Rider OS's Bookings, Finance OS's Net Worth and Financial
  Timeline, a future Property OS's Timeline, etc).

RELATIONSHIP DECLARATIONS
---------------------------------------------------------------------
  To UEF:              Fully adopted (ADR-001). Engineering discipline
                        is orthogonal to whether a project is a Domain.
                        NOTE (ADR-017): UEF v1.12's own Scope line does
                        not name Execution OS — it lists Domain OS
                        projects by name plus "every future Domain OS
                        project," and this project explicitly isn't
                        one. This adoption is a voluntary extension
                        beyond UEF's literal stated scope, not a claim
                        that UEF's text already asserts jurisdiction
                        here. Does not require UEF itself to change.
  To Blueprint:         Selectively adopted (ADR-001). Reuses capability
                        nodes (Schema, Event Definitions, Query,
                        Connectors, etc.) but does NOT adopt Blueprint's
                        implicit "a Domain owns its business Schema"
                        assumption — Execution OS's Foundation Schema
                        defines only its own native entities.
  To Personal AI Core:  Sibling project. Runs its OWN independent
                        instance of the ecosystem's Telegram-bot and
                        EventBus-Adapter patterns (ADR-016) — this
                        means a separate bot/webhook, following the
                        same pattern Rider OS already uses, not a
                        shared webhook with Personal AI Core. Does NOT
                        share a Spreadsheet with Domains either
                        (ADR-012 — Execution OS has its own,
                        independent Spreadsheet, read-only toward the
                        Domain-shared backend, never writes to it).
                        Telegram-entry independence does NOT imply AI
                        Infrastructure independence — see ADR-013/015.
  To every Domain OS:   Read-only, one-directional observation via
                        Execution Reference. Never writes, never
                        copies, never owns.

ARCHITECTURE LAYER MAPPING (per Blueprint BP-6 — instantiation lives
in the project, not the Blueprint document)
---------------------------------------------------------------------
  Blueprint layer     | Execution OS instantiation
  --------------------|---------------------------------------------
  0. Governance        | Points to UEF, per BP-1. This file + Business
                        | Rules + Project State + File Map + ADR Log.
  1. Foundation         | Schema defines ONLY native entities (Vision,
                        | Goal, Execution Project, Reference, Waiting,
                        | Review, Execution Event) — never Business
                        | Schema. Permissions node not designed
                        | (single-user system, EP3).
  2. Runtime            | Request (Telegram entry), Event (own event
                        | stream + Domain event subscription), Query
                        | (Today/Week View reads). Planner (Planning
                        | Engine) and Projection (Today/Week/Dashboard)
                        | map to Blueprint nodes still at Tier 2 —
                        | Execution OS's own implementation does NOT
                        | automatically count toward promoting those
                        | to Tier 1; Blueprint's stated trigger language
                        | is scoped to "a second Domain OS project,"
                        | and Execution OS is explicitly not one (see
                        | ADR-001). Decision/User Confirmation nodes
                        | not designed yet.
  3. Intelligence        | AI Planning Connector = Execution OS's own
                        | "AI Capability," built on Personal AI Core's
                        | "AI Infrastructure" (ADR-013; see candidate
                        | principle in 00_ADR_Log.js).
  4. Integration         | Domain Adapter Registry = a more formal,
                        | novel instantiation of Blueprint's Bridge
                        | node (currently Tier 2, evidenced only by
                        | "the shared Sheet used informally as a
                        | bridge" — this is NOT reuse of an existing
                        | standard pattern, it is a new implementation
                        | of the same concept).
  5. Testing             | Same automated-unit-tests + manual-checklist
                        | convention as the rest of the ecosystem.
  Cross-Cutting          | Reuses Observability/Diagnostics (Tier 2).
                        | Security/Telemetry not designed (Tier 3,
                        | zero evidence).

PLATFORM CONSTRAINTS (per UEF v1.12 S2, added here 2026-09-12)
---------------------------------------------------------------------
Execution OS runs on Google Apps Script + Google Sheets as its Truth
Layer, same as every other project in this ecosystem. Two consequences
that follow directly and already apply to decisions already made:
  - No multi-statement transactions. ADR-007's completion write-back
    (Execution publishes an Execution Event; a Domain optionally
    writes its own state) is two independent, non-atomic operations,
    not one. This was already true; it is stated here for the first
    time rather than left implicit.
  - No real concurrency beyond LockService, and LockService is
    per-script only — it does not coordinate across projects sharing
    the Domain backend Sheet.

Owner-stated working practice (2026-10-27; the owner's words: "我所有的
os都是在gas跑通的" — every one of the owner's OSes is made to work in
real Google Apps Script), recorded as given. Read it as: the Node
sandbox passes so far are a preliminary check, and the owner's own
practice is to make each OS work in real GAS. Whether that becomes a
formal Definition-of-Done criterion is open item 9 in 00_Project_
State.js — not decided here. It does not say that any Execution OS file
has been run in GAS: no record of that exists. (Added 2026-10-31: the
tool for making that record for 15_TruthEngine.js now exists —
runTruthEngineGate() in 90_UnitTests.js, run by hand in the Apps Script
editor — but it has not been run, so the sentence above still holds.
Updated 2026-11-03: it was run once, on 2026-11-03, and so a record now
exists that 15_TruthEngine.js, and the files it calls, ran in real GAS
(00_Project_State.js, 2026-11-03 entry). The sentence above is about
every Execution OS file; it is no longer true of that one.)

CHECKPOINT INTEGRITY GATE (ADR-018, added here 2026-10-08)
---------------------------------------------------------------------
Beyond UEF v1.12 S0.6's own File->Export->Read-back->Verify->Test->
Evidence sequence (which verifies the file just written), every
checkpoint on this project also: (1) re-verifies the working
directory against the last accepted checkpoint before starting any
new file — content-checked, not just filenames confirmed present;
(2) repeats that check before declaring a checkpoint PASS, not only
right after a dependency was first written. A missing dependency,
an unclear recovery source, or an unexplained state difference is a
STOP, never a mock or a memory-reconstructed stand-in for a real
file. Adopted after a real container-reset incident silently
dropped every previously-checkpointed file between sessions — see
ADR-018 for the full record.

WORKING RULES (ADR-019, ADR-020 — Accepted; added here 2026-11-01)
---------------------------------------------------------------------
Two rules govern how work on this project is done. Both are the
owner's own instructions and were in force before they were written
down as ADRs:
  - Work boundary (ADR-019): only Execution OS is modified. Every other
    OS (Personal Life OS, Personal AI Core, Rider OS, Reminder OS, any
    other) is read-only reference: read, never written, never copied
    into this repository. If something must change in a sibling, it is
    flagged for the owner to apply. The owner's words, 2026-10-24:
    "这个os是以execution os开发为主。其他的os只能read only".
  - One file per explicit authorization (ADR-020): each file is built on
    its own go-ahead (or each named step of a request). A checkpoint
    ends with governance synced (BR-9), delivery, a "Scope respected"
    statement and a STOP; the next file starts only on its own
    go-ahead. The owner's words, 2026-11-01: "完成 checkpoint、
    Governance/ADR 持久化及核对后就停止，不要继续 coding".

PROPOSED PRACTICES (ADR-021 to ADR-024 — PROPOSED, NOT ratified by the
owner; added here 2026-11-01)
---------------------------------------------------------------------
Built or in use, but the builder's choices. None is an approved
decision and no later file may treat one as settled. Each is recorded in
00_ADR_Log.js; the questions still open on each are in 00_Project_
State.js (WHAT IS STILL OPEN):
  - ADR-021 deployment packaging: .claspignore, appsscript.json and the
    naming rules they imply (a name ending in _Test.js is Node-only and
    never pushed; a name starting with 00_ is comment-only and never
    pushed). Item 14.
  - ADR-022 the TruthEngine write path, choices P1 to P11 in
    15_TruthEngine.js's header (P10 and P11 added 2026-11-03). Item 11.
  - ADR-023 real-GAS verification by the hand-run gate function in
    90_UnitTests.js. The gate was run once, 2026-11-03 (it had not been
    run when this was written, 2026-11-01). Item 15.
  - ADR-024 verification and reporting discipline: a sandbox result is
    never reported as a real-GAS result; evidence is labelled by tier;
    test code that guards a write path is checked by planting defects;
    harness bugs, production defects and the builder's own mistakes are
    reported separately. Item 9 could take it into a Definition of Done.

DISAMBIGUATION NOTE
---------------------------------------------------------------------
Blueprint's Runtime layer has a node literally named "Execution"
(the service/action layer, Tier 1). This is NOT the same thing as
the project "Execution OS." Any reference to "Runtime > Execution"
in this governance set means the Blueprint node, not this project.

FULL REFERENCE DOCUMENT
---------------------------------------------------------------------
The complete architecture narrative (Data Ownership schemas, Execution
Flow diagrams, Cross-Domain Integration mechanics, Google Sheets
tab/field design, Personal AI Core interface questions) lives in the
companion reference document, not duplicated here per EP2 (one source
of truth): Execution_OS_Architecture_v0.8.md
*/
