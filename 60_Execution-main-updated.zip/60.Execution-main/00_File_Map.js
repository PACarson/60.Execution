/*
=====================================================================
EXECUTION OS — FILE MAP
=====================================================================
Status: mostly PROPOSED numbering; Foundation 10_Config.js/
11_Schema.js/12_Identity.js are the exceptions — built and
checkpointed (see 00_Project_State.js's checkpoint log for each).
Everything else below is still a plan for when implementation
reaches it, not an inventory of real files. Extension is .js per
Steven's confirmed convention, confirmed 2026-09-12 to exactly match
UEF v1.12's D8 decision (read directly, not from ecosystem memory).

NARROW GOVERNANCE REPAIR, 2026-10-04: the FOUNDATION (10-19) block
below previously still listed this project's original, pre-
reconciliation numbering (10_Schema.js/11_EventDefinitions.js/
13_Permissions.js/14_Versioning.js, with no 15-19 entries) even
though the 2026-09-12/13 Foundation Dependency Reconciliation had
already superseded it — the reconciled numbering was presented in
that round's response but never actually written into this file.
Repaired below to match what was actually decided and, for 10-12,
actually built. Scope of this repair is this block only — see the
RUNTIME-section note further down for a related, separate, still-
open question this repair deliberately did not touch.

GOVERNANCE (this set — the five files delivered alongside this one)
  00_Project_Constitution.js
  00_Business_Rules.js
  00_Project_State.js
  00_File_Map.js  (this file)
  00_ADR_Log.js

FOUNDATION (10-19)
  10_Config.js              Configuration only — Spreadsheet ID,
                             active AI Adapter selection (ADR-015),
                             Telegram bot token slot (ADR-016), all
                             from Script Properties, no setters.
                             BUILT — checkpointed and passed 2026-09-14.
  11_Schema.js              Bootstrap / structural schema owner —
                             idempotent tab + header creation and
                             verification only, never a data-row
                             append. Does NOT depend on
                             15_TruthEngine.js: structural setup and
                             data-row persistence are separate
                             concerns that only share a build-order
                             sequencing note, not a code dependency
                             (Foundation Dependency Reconciliation,
                             2026-09-13). Only hardcodes
                             Execution_References' ADR-008/010-locked
                             field set; no other entity's business
                             fields. BUILT — checkpointed and passed
                             2026-09-16.
  12_Identity.js            Canonical ID generation only — stateless,
                             {PREFIX}-{timestamp}-{random} shape, no
                             Sheet-backed counter. No hardcoded
                             entity-prefix registry: prefixes are
                             caller-supplied and only structurally
                             validated, since no Engine owning
                             GOAL/XPRJ/REF/WAIT/VIS exists yet.
                             BUILT — checkpointed and passed 2026-10-03.
  13_EventDefinitions.js    Execution's own Event vocabulary — defines
                             which event types are legal. Does NOT
                             persist them; that is 16_EventLog.js's
                             job, a separate file and a separate
                             concern. Real precedent already in
                             Execution_OS_Architecture_v0.8.md:
                             goal.created, execution_project.
                             status_changed, review.completed,
                             execution.reference_completed (lowercase
                             entity.action), explicitly not an
                             exhaustive list. isLegalEventType() is
                             true only for goal.created/review.completed
                             (CONFIRMED tier); the other two stay
                             OBSERVED, not silently promoted. BUILT —
                             checkpointed and passed 2026-10-04/05.
  14_Versioning.js          Minimal hash/timestamp/version utility —
                             computeContentHash(fields) and
                             isNewerThan(a,b) only; no schema-version
                             stamp (no real evidence found for one).
                             Deliberately scoped narrow — no
                             speculative concurrency-control framework
                             (EP3) until a real, observed need exists.
                             BUILT — checkpointed and passed 2026-10-06.
  15_TruthEngine.js         Generic validated safe append/write owner,
                             per UCR6 — every Engine's data-row append
                             goes through this file, not its own raw
                             appendRow(). Schema-agnostic on purpose:
                             it does not know or enforce any entity's
                             field shape, only that an append is
                             locked and safe. Planned / not yet
                             implemented.
  16_EventLog.js            Event append/read for Execution_Events,
                             validating each event's type against
                             13_EventDefinitions.js's vocabulary
                             before writing, via 15_TruthEngine.js.
                             Planned / not yet implemented.
  17_ReferenceBase.js       Reference entity shape, validation,
                             normalization, and snapshot/hash
                             preparation ONLY — this file does not
                             perform persistence. Execution_Reference
                             rows are actually written by a Runtime-
                             layer Engine (see the RUNTIME-section note
                             below), which calls 15_TruthEngine.js;
                             17_ReferenceBase.js has no Sheet access of
                             its own. Planned / not yet implemented.
  19_Utils.js               Generic, non-entity-specific shared
                             helpers only. Planned / not yet
                             implemented.

NOTE (found during this repair, deliberately NOT acted on — out of
this repair's scope, which is the Foundation block only): the
Foundation Dependency Reconciliation also called for a
26_ReferenceEngine.js in RUNTIME (Reference persistence — the Engine
that actually calls 15_TruthEngine.js on 17_ReferenceBase.js's
behalf, since ReferenceBase itself has no Sheet access). The RUNTIME
list below has never actually dropped 27_PlanningEngine.js — that
concern turned out to be about an earlier Implementation Master Plan
draft conflating Planning with AI Planning, not about this file —
but it has no ReferenceEngine entry at all, and adding one without
also resolving numbering against the existing 26_WeekViewEngine.js
is exactly the kind of RUNTIME-section change this repair's own
scope excludes. Flagged for a separate, future RUNTIME reconciliation
round, not fixed here.

RUNTIME (20-34)
  20_Router.js              Receives from Execution OS's OWN
                             independent Telegram Bot (ADR-016) — not
                             from Personal AI Core's webhook
  21_Parser.js
  22_VisionEngine.js
  23_GoalEngine.js
  24_ExecutionProjectEngine.js
  25_TodayViewEngine.js
  26_WeekViewEngine.js
  27_PlanningEngine.js
  28_DashboardEngine.js
  29_ReviewEngine.js
  30_WaitingEngine.js
  31_ExecutionEventEngine.js

INTELLIGENCE (40-49)
  40_AIPlanningConnector.js       Execution OS's own "AI Capability,"
                                  built on Personal AI Core's "AI
                                  Infrastructure" (see candidate
                                  principles in 00_ADR_Log.js)
  41_GoalDecompositionAssist.js
  42_PrioritySuggestion.js

INTEGRATION (50-59)
  50_DomainAdapterRegistry.js     All cross-Domain field-mapping
                                  config lives here — per UCR7
                                  (Infrastructure Adapter/Port
                                  isolation, confirmed 2026-09-12
                                  against UEF v1.12's actual S4 text,
                                  added v1.4), when a real dependency
                                  (e.g. Personal AI Core's routing
                                  mechanism) isn't confirmed yet, this
                                  file should get a logged placeholder
                                  Adapter rather than a guessed
                                  signature — this project's own
                                  design reached the same conclusion
                                  independently, before reading UCR7's
                                  real text
  54_AIProviderInterface.js       AI Provider Interface (ADR-015) —
                                  Execution AI Capability calls this,
                                  never a provider directly. Its
                                  Transitional Direct LLM Adapter is
                                  explicitly temporary; removed per
                                  ADR-015's Review Trigger, not on a
                                  calendar schedule
  51_ReferenceSync.js
  52_ReminderOSAdapter.js
  53_PersonalAICoreAdapter.js

CROSS-CUTTING (60-69)
  60_Observability.js
  61_Diagnostics.js

TESTING (90-99)
  90_UnitTests.js
  91_ManualChecklists.js

DEPENDENCY RULES (per UEF v1.12 S2 — since these are independent GAS
deployments sharing only a Sheet, a "dependency" means this project
assumes another project populates a specific Sheet/tab. Every such
assumption gets one line here; UEF requires the matching line also
exist in the other project's own File_Map, which this project cannot
verify or add on its own.)
  51_ReferenceSync.js reading the Domain-shared backend assumes tabs
    named approximately: Events, Tasks, ActiveTasks, ArchiveTasks,
    TaskStatistics, TaskFilters, ReminderRules, ReminderOccurrences,
    ReminderHistory.
  STATUS: Unknown / Not Verified. This list was supplied by Steven/
  relayed content in an earlier round, not read from live Sheet
  structure or Personal Life OS's own File_Map. Per the 2026-09-12
  Post-Reconciliation Decision (Decision 4): do not infer real tab
  names from filenames, memory, or this project's own conversation
  history. Verification Required Before Any Implementation Depending
  On These Tables — i.e. before 51_ReferenceSync.js is actually
  written, not before Foundation-layer work in general.

OPEN NUMBERING QUESTION (ADR-006 covers the base choice; unresolved
detail): if the "Jarvis AI Ecosystem" shared-directory plan happens,
this numbering needs reconciling with Finance OS's proposed 900/100
block scheme to avoid collisions.
*/
