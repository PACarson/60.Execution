/*
=====================================================================
EXECUTION OS — PROJECT STATE
=====================================================================
Last updated: 2026-09-12 (Governance Reconciliation + Post-
Reconciliation Decision & Governance Closure, same day — see
Execution_OS_Governance_Reconciliation_2026-09-12.md for the full
audit this update is based on)

GOVERNANCE STATUS: Governance Reconciliation Closed / Governance
Ready. This is NOT the same as ready for implementation — per
Steven's explicit instruction, this status only means governance
questions are resolved to the extent evidence allows; a separate,
explicit go-ahead is required before Implementation Planning / Slice
Definition begins, and another before actual coding begins.

DESIGN VERSION: v0.8 (Execution_OS_Architecture_v0.8.md) — NOTE: the
Architecture doc's own section 9 has not yet been updated to reflect
ADR-015/016/017 or the ADR-013/014 evidence updates below; that sync
is a tracked gap, not done as part of this update (see WHAT IS STILL
OPEN, item 7).

CODE STATE: ZERO. No GAS file, no Sheet, no Telegram command, no
test, has been written for this project. Everything in this
governance set is a design decision, not an implemented one. Do not
read any "Accepted" ADR as "built" — Accepted means "the design
decision is settled," nothing more.

DEFINITION-OF-READY / DONE / PRODUCTION-READY STATUS (per UEF S0.5):
  Definition of Ready:   NOT MET. No live-schema change is being made
                          (there is no live schema), and while several
                          governing decisions exist (ADR-001 etc.),
                          implementation has not begun.
  Definition of Done:    NOT MET. No code, no tests, no Change Impact
                          Analysis has been reported (there is nothing
                          to report against yet).
  Definition of Production-Ready: NOT MET, not applicable yet.

WHAT IS ACCEPTED (design-level, not code-level) — see 00_ADR_Log.js
for the full list of ADR-000 through ADR-017. Headline items:
  - Execution OS is not a Domain OS; UEF fully adopted, Blueprint
    selectively adopted (ADR-001); this adoption is a voluntary
    extension beyond UEF's own literal Scope line, which does not
    name Execution OS (ADR-017, 2026-09-12)
  - Reference-only data ownership, zero Domain data duplication
    (ADR-002)
  - Zero-modification cross-Domain integration via event subscription
    + reconciliation backstop (ADR-003) — "subscription" in practice
    means an Adapter reading the shared Events Sheet, not a push
    mechanism (clarified 2026-09-12)
  - Renamed from "Life Execution OS" to "Execution OS" (ADR-009)
  - Independent Spreadsheet, read-only toward the Domain-shared
    backend (ADR-012)
  - AI calls route through Personal AI Core as the TARGET architecture
    (ADR-013) — Personal AI Core confirmed 2026-09-12 to have no such
    layer yet; the transitional path until it exists is an AI Provider
    Interface + Temporary Direct LLM Adapter (ADR-015, 2026-09-12)
  - Execution OS owns its own independent Telegram Bot, separate from
    Personal AI Core's webhook, following Rider OS's proven pattern
    (ADR-016, 2026-09-12)

RESOLVED 2026-09-12 (were items 1/2/3/5/6 below — see
Execution_OS_Governance_Reconciliation_2026-09-12.md for full
evidence): Personal AI Core's command-routing mechanism (single
webhook, hardcoded sequential chain, not dynamically extensible —
ADR-016); Personal AI Core's centralized AI-calling layer (confirmed
absent — ADR-013/015); Productivity OS's fitness to become Personal
Life OS (already happened, mature, is the ecosystem's reference
implementation); the EventBus's real nature (shared Sheet + per-
project local Adapter code, not a message bus — matches UEF v1.12's
own framing of it as a stated future Platform Capability, not yet
built); UEF's Version Dependency (confirmed v1.12, full text read,
D8/UCR7 confirmed exactly, several previously-unknown S0.6/S2 rules
surfaced — see ADR-014).

WHAT IS STILL OPEN:
  1. Reminder OS's own unresolved Phase B question ("Reminder Rules
     storage" / "Scheduler Integration") overlaps with Execution OS's
     scheduling dependency (Review Engine, Reference Sync periodic
     triggers, avoiding GAS's 20-trigger-per-project quota) — needs to
     be designed together, not assumed. Unchanged by this round;
     nothing read touched this specific question.
  2. Domain-shared backend's actual tab list (Events, Tasks,
     ActiveTasks, etc. — ADR-012's evidence caveat) is still Unknown /
     Not Verified. Per the 2026-09-12 Decision 4: do not infer it from
     filenames or memory. Verification required before
     51_ReferenceSync.js is written (see 00_File_Map.js Dependency
     Rules), not before Foundation-layer work in general.
  3. Architecture_v0.8.md's section 9 (the reasoning record) has not
     been updated to match ADR-015/016/017 or the ADR-013/014
     evidence updates in 00_ADR_Log.js. Documentation drift (EP2),
     tracked here, not yet fixed.
  4. AI Provider Interface's (ADR-015) exact request/response shape
     is not yet defined — deferred to when 40_AIPlanningConnector.js
     is actually built, per that ADR's own Next Steps.
  5. Rider OS's own Telegram bot was never directly read this round —
     its independence from Personal AI Core's webhook is inferred
     from 80_RiderConnector.js's one-way-read framing and the absence
     of a Rider-intent branch in Core's _handleMessage_, not confirmed
     by reading Rider OS's own code. ADR-016 flags this explicitly.
  6. A "Decision OS" was named in an unrelated draft document with no
     corroborating evidence anywhere else. Not introduced, no
     dependency created, per the 2026-09-12 Post-Reconciliation brief.
     Revisit only if real evidence surfaces.
  7. Whether UEF's own Scope line should be clarified to address
     coordinator-type projects like this one is flagged as a
     candidate "UEF Change Proposal Required" (ADR-017) — this is
     not something Execution OS can decide or act on; noted for
     whoever maintains UEF's own process.
  8. UEF S0.6 item 4's ecosystem-level `Universal-Recovery-Manifest.md`
     (for cross-project/cross-session checkpoint tracking, referenced
     via a `00-INDEX.md` this project does not have access to) has not
     been created or located — this project can record its OWN
     checkpoints in this file once implementation starts, but cannot
     verify or create the ecosystem-level manifest itself.

IMPLEMENTATION CHECKPOINT LOG (per UEF v1.12 S0.6 item 4, adopted
2026-09-12 — Decision 3 of the Post-Reconciliation brief). Empty
until Foundation-layer implementation actually begins; scaffolded
now so the discipline is in place from the first file written, not
retrofitted after an incident. Per file: implement -> export/persist
immediately -> verify the persisted copy is readable -> self-check.
Per Engine: all its files checkpointed. Per Sprint: all its Engines
checkpointed. Any work spanning this project plus another project or
AI session additionally needs an entry in the ecosystem-level
Universal-Recovery-Manifest.md (see WHAT IS STILL OPEN, item 8 — this
project cannot create that file itself).
  File checkpoints:
    2026-09-12/14 — 60_Observability.js (AlertService, UCR3 owner).
      Exported. Read back from disk, matched intended content exactly.
      Verified against UEF v1.12 UCR3 text (re-read directly this
      checkpoint, not from memory). 10/10 executable tests passed
      (60_Observability_Test.js, Node vm sandbox stubbing Logger,
      same approach as [[reminder-os]]'s own run_reminder_tests.js
      precedent) — note for honesty: the first test run failed 10/10
      on a harness bug (Node's vm module doesn't expose top-level
      const bindings as sandbox properties), not a bug in the file
      under test; fixed the harness, reran, then 10/10 passed.
      node --check syntax-clean. Confirmed via `find -newer` that no
      other file changed as a side effect. Scope respected: only
      this file + its test file created; Config/Schema/other OS's/
      Telegram/LLM untouched, per the 2026-09-12 authorization.
    2026-09-14 — 10_Config.js (Spreadsheet ID / active AI Adapter /
      Telegram bot token slot). Exported. Read back from disk,
      matched intended content exactly. 14/14 executable tests
      passed on first run (10_Config_Test.js, same Node vm-sandbox
      approach, PropertiesService additionally stubbed) — covering
      valid retrieval, missing-required-value throw (Spreadsheet ID),
      default-on-missing (Active Adapter, per ADR-015), invalid-value
      fallback, UCR3 AlertService routing for both the throw and the
      fallback-warning paths, frozen constants, absence of any
      setter, and absence of any SpreadsheetApp/UrlFetchApp reference
      (left undefined in the sandbox; nothing threw). node --check
      syntax-clean. `find -newer` confirmed no other file changed.
      Scope respected: only this file + its test file created; no
      Schema/Identity/EventDefinitions/Versioning/TruthEngine/
      EventLog/ReferenceBase/Router/Parser/PlanningEngine/AI/
      Telegram/other-OS work done, per the 2026-09-14 authorization.
    2026-09-16 — 11_Schema.js (bootstrap tab/header creation and
      verification; Execution_References is the only schema
      hardcoded, its 13-field list re-verified against
      Execution_OS_Architecture_v0.8.md S3.2 directly this
      checkpoint, not from memory — an earlier draft had actually
      missed ai_recommended_priority/created_at until this re-check).
      Exported. Read back from disk, matched intended content
      exactly. 18/18 sandbox-logic tests passed (11_Schema_Test.js,
      Node vm sandbox with a hand-built fake SpreadsheetApp) after
      fixing 3 bugs in the TEST HARNESS itself, not in 11_Schema.js:
      (a) comparing arrays that crossed the vm sandbox/main-realm
      boundary tripped assert.deepStrictEqual's prototype check
      despite identical content — fixed by normalizing both sides
      through a JSON round-trip before comparing; (b) a naive
      source-text check for the word "TruthEngine" incorrectly
      flagged this file's own header comment explaining why there is
      NO such dependency — fixed to check for an actual "TruthEngine."
      call pattern instead; (c) a test expected Array.prototype.push
      on a frozen array to fail silently, but push throws per spec on
      any non-extensible array regardless of strict mode — the throw
      was actually proof the freeze worked; fixed the test to expect
      and confirm that throw instead of treating it as a failure.
      Covered: missing-tab creation, existing-empty-tab, idempotency
      (running twice makes no further change), non-destructive on
      existing data rows, safe additive header extension (append-only,
      existing columns untouched), hard-stop on a real column
      mismatch (throws, writes nothing), Config's missing-Spreadsheet-
      ID error propagating rather than being swallowed, UCR3 routing
      for both the INFO/WARN/ERROR paths, frozen constants, and
      confirmation this file never calls TruthEngine. node --check
      syntax-clean. `find -newer 10_Config.js` confirmed only this
      file and its test file are new.
      REAL_GAS_REQUIRED — explicitly NOT verified by anything above,
      and not verifiable from this container: whether
      SpreadsheetApp.openById()/insertSheet()/getSheetByName() behave
      as mocked against a real Spreadsheet, whether a real header
      write via getRange().setValues() actually persists, behavior
      under real concurrent access, and real execution-time limits on
      a large existing sheet. Carson still needs to run this against
      a real GAS project before treating Schema as production-ready,
      not just logic-verified.
      Scope respected: only Schema + its test file created; no
      Identity/EventDefinitions/Versioning/TruthEngine/EventLog/
      ReferenceBase/Router/Parser/PlanningEngine/AI/Telegram/other-OS
      work done, per the 2026-09-16 authorization.
    2026-10-01/03 — 12_Identity.js (stateless canonical ID
      generation; format {PREFIX}-{base36 timestamp}-{6-char random
      suffix}; no entity-prefix registry hardcoded — prefixes are
      caller-supplied and only structurally validated, since no
      Engine owning GOAL/XPRJ/REF/WAIT/VIS exists yet). Source-of-
      truth check performed before writing any code: grepped
      00_File_Map.js/00_Project_State.js/Architecture doc for a
      locked ID format — none exists; the 2026-09-12 Foundation
      Dependency Reconciliation's GOAL-/XPRJ-/REF- prefix list was a
      Proposal, never Accepted, so nothing in this file depends on
      those specific strings being final. Exported, read back,
      matched. Uses no Google-runtime global at all (not even
      AlertService on its success path — only the failure path calls
      it, per UCR3's actual text, which describes catch-block
      behavior, not a mandate to log every success; this matches the
      no-INFO-on-clean-success precedent already set by Config and
      Schema). 17/17 tests passed, after fixing one real test-
      organization bug, found and explained in full below under the
      recovery incident (format-validation/rejection tests were
      originally run against the zero-globals sandbox, which doesn't
      have AlertService — but rejecting an invalid prefix goes
      through the catch block, which does call it; fixed by giving
      those tests the sandbox that actually loads
      60_Observability.js). No REAL_GAS_REQUIRED items — generateId()
      touches no GAS-specific API at all, verified by running its
      success path with zero globals defined.
      Scope respected: only Identity + its test file created (plus
      the recovery work below, which touched no NEW runtime logic,
      only restored/merged existing files and this log) — no
      EventDefinitions/Versioning/TruthEngine/EventLog/ReferenceBase/
      Router/Parser/PlanningEngine/AI/Telegram/other-OS work done.
    2026-10-04 — 13_EventDefinitions.js (legal Execution Event
      vocabulary query). Governance source review performed fresh
      this checkpoint, not from memory or the prior chat summary:
      re-read Architecture S2.4 and Flows B/E/G directly, grepped
      00_ADR_Log.js for any event-vocabulary ADR (none exists). Found
      the 4 known event-name strings split into two real evidentiary
      tiers, not one: CONFIRMED (goal.created, review.completed —
      each named in both S2.4's list AND a definite, unhedged Flow)
      vs. OBSERVED (execution_project.status_changed — S2.4 list
      only, no corroborating Flow; execution.reference_completed —
      Flow G, but explicitly hedged with "如" (e.g.), meaning the doc
      itself treats this exact string as illustrative, not committed
      — though the underlying publish-on-completion mechanism it
      would represent IS Accepted, as ADR-007; only this specific
      spelling is not). isLegalEventType() is true only for the
      CONFIRMED pair; getEvidence() exposes the full tier for any
      string rather than collapsing CONFIRMED/OBSERVED into one
      boolean. Deliberately did NOT add any of this project's own
      earlier-proposed (Implementation Master Plan) event-name
      extensions — those stay Proposed, not Accepted, and including
      them now would have been exactly the "make the registry look
      complete" overreach this checkpoint's own authorization warned
      against. Exported, read back, matched. 17/17 tests passed
      after fixing one test-harness bug (checking Object.keys on the
      vm sandbox's outer object, which never reflects a const
      binding — same root cause as the bug found and fixed in
      12_Identity_Test.js — not a bug in 13_EventDefinitions.js;
      fixed by querying `typeof <global>` inside the context instead
      of inspecting the wrapper object's own properties). No
      REAL_GAS_REQUIRED items — this file touches no GAS-specific
      API at all. Acceptance Integrity Gate: all 5 checkpoints'
      tests re-run together, 76/76 passing; `find -newer
      00_File_Map.js` confirmed only this file and its test are new.
      Scope respected: no File_Map/ADR/Architecture/Master-Plan/
      Observability/other-source-file changes; no
      Versioning/TruthEngine/EventLog/ReferenceBase/Router/Parser/
      PlanningEngine/AI/Telegram/other-OS work done.
    2026-10-06 — 14_Versioning.js (generic content-hash +
      timestamp-comparison primitives only). Source-of-truth
      verification: re-read ADR-010 and Architecture S3.2 directly.
      Found the real requirement is narrower than "versioning" as a
      general concept — snapshot_hash is a content fingerprint taken
      ONLY over the snapshot_* fields, for ONE purpose (cheap re-sync
      change-detection), and the Architecture doc's own line 728
      records an earlier, more general "version tracking" idea as
      explicitly SUPERSEDED by this simpler approach. A schema-
      version-stamp idea floated during the Foundation Dependency
      Reconciliation was NOT carried forward here — that came from
      this project's own earlier speculation, not from any ADR or
      Architecture evidence found this round, so per this
      authorization's "no real requirement, don't design it" rule it
      is left out. Concurrency control re-confirmed DEFERRED, no new
      evidence for it either. Ownership: computeContentHash(fields)
      is fully generic (caller supplies whatever fields matter to
      it — this file has no Reference-specific knowledge);
      isNewerThan(a, b) normalizes Date/epoch-number/ISO-string
      inputs. Canonicalization is explicit: keys sorted before
      hashing (order-independence), undefined/null get distinct
      markers rather than JSON.stringify's silent-drop behavior, no
      timestamp is ever added automatically — all verified by test,
      not just asserted. Hash algorithm is FNV-1a (32-bit,
      non-cryptographic), chosen and documented as adequate for the
      actual "cheap change-detection" purpose, not for security.
      Exported, read back, matched. 24/24 tests passed — but only
      after finding and fixing ONE REAL PRODUCTION DEFECT, not a test
      artifact: `_toEpochMillis_` originally used `instanceof Date`,
      which is unreliable across any boundary where a Date wasn't
      constructed by the exact same realm's Date constructor (caught
      via the test harness's vm sandboxing, confirmed by direct
      reproduction — a host-realm Date failed `instanceof` against
      the sandbox's own Date). Fixed by duck-typing on a `getTime`
      method instead, which is strictly more robust and accepts any
      real Date regardless of origin. This is a genuine improvement
      to the shipped file, not a test-only workaround. No
      REAL_GAS_REQUIRED items — touches no GAS-specific API.
      Acceptance Integrity Gate: all 6 checkpoints' tests re-run
      together, 100/100 passing; `find -newer` confirmed only
      Versioning + its test (+ this log) changed; grepped the file
      directly for LockService/migration/transaction/revision —the
      one match is the "Does NOT use" documentation line itself, no
      functional code of that kind exists.
      Scope respected: no File_Map/ADR/Architecture/Master-Plan/
      other-source-file changes; no TruthEngine/EventLog/
      ReferenceBase/Router/Parser/PlanningEngine/AI/Telegram/
      other-OS/RUNTIME-reconciliation work done.
  Engine checkpoints: (none yet — Observability/Config/Schema/
    Identity are all standalone Foundation files, not yet grouped
    into a Slice 0 Engine checkpoint)
  Sprint checkpoints: (none yet — Slice 0 not complete)

CONTAINER RESET / RECOVERY INCIDENT — 2026-10-01
  Finding: starting the 12_Identity.js checkpoint, the live container's
  working directory was found to contain only the 2 files just
  written (12_Identity.js, 12_Identity_Test.js) — every previously
  checkpointed file (all 5 governance files incl. this one, the
  Architecture doc, and 60_Observability.js/10_Config.js/11_Schema.js
  with their tests) was gone from the live filesystem. Surfaced
  indirectly: 12_Identity.js's own test tried to load
  60_Observability.js for its UCR3 check and got ENOENT, not a logic
  failure.
  Cause: a container reset between sessions/tasks, exactly the
  failure mode UEF v1.12 S0.6 item 4 was written to catch (per its
  own text, prompted by a prior real incident of the same kind,
  elsewhere in this ecosystem).
  Recovery: Carson confirmed. Before touching anything, the 2 new
  files were copied to a separate, untouched location and MD5-
  verified byte-for-byte against the originals. The last successfully
  delivered zip (60_Execution-main-updated.zip, from the 11_Schema.js
  checkpoint) was extracted to a SEPARATE inspection directory first —
  not directly over the live one — and checked for any filename
  overlap with the 2 new files before merging; there was none. Key
  restored files were content-checked, not just confirmed to exist:
  00_ADR_Log.js's 18 real ADR entries (ADR-000 through ADR-017) were
  enumerated by line number and title; this file's own checkpoint log
  was confirmed to already contain the 11_Schema.js entry;
  11_Schema.js's hardcoded field list was confirmed to contain the
  ai_recommended_priority/created_at fields the 2026-09-16 checkpoint
  had specifically caught itself missing in an earlier draft. Only
  after all of that did the 13 restored files get copied into the
  live working directory alongside the 2 preserved ones (an additive
  merge, not an overwrite — MD5-reconfirmed identical after). Then,
  and only then, were 12_Identity.js's tests re-run against the real
  60_Observability.js, which is what surfaced the test-organization
  bug described in the checkpoint entry above.
  No data was actually lost: the last delivered zip had everything.
  What was genuinely exposed is a gap in process, not in any file's
  content — see below.

CHECKPOINT INTEGRITY GATE — adopted 2026-10-03, Execution OS's own
project-level practice from this point forward (not a change to
UEF's text itself — see the evaluation note below):
  1. Before starting any new file or module, verify the working
     directory's actual state against this log's own record of what
     should already exist there — not just that the specific file
     about to be touched is absent, but that everything the LAST
     accepted checkpoint implies should be present actually is.
  2. Before accepting any checkpoint (i.e. before updating this log
     to mark something passed), re-verify file integrity and version
     for anything that checkpoint's tests depend on, again — not
     only right after the dependency was first written.
  3. If a dependency is missing, state is inconsistent, or a
     recovery source is unclear: STOP. Never paper over it with a
     temporary mock standing in for a real sibling file, and never
     silently reconstruct a file from memory instead of restoring it
     from a verified source. Report and wait, the same as for any
     other architecture ambiguity.
  Why this is a gap the existing discipline didn't cover: UEF v1.12
  S0.6's File-Export-Readback-Verify-Test-Evidence sequence verifies
  the NEW file being written at that moment. It has no step that
  checks whether files from EARLIER checkpoints are still actually
  there before building on top of them -- which is exactly how this
  incident went unnoticed until a test happened to need a missing
  sibling. This Gate is the missing complement, not a replacement.

  UEF v1.12 S0.6 amendment evaluation (flagged, not acted on — this
  project does not self-modify UEF's text, same principle as
  ADR-017's handling of the Scope question): this incident is
  concrete, repeatable evidence that S0.6 item 4's checkpoint-
  recording requirement has a gap on the READING side — it records
  that a checkpoint happened, but nothing in its text requires
  re-verifying that a PRIOR checkpoint's files are still present
  before relying on them. Worth proposing as a UEF Change Proposal
  (a "Checkpoint Integrity" sub-item under S0.6) to whoever maintains
  UEF's own governance process; this project adopts the practice for
  itself in the meantime, which it can do unilaterally, the same way
  it adopted S0.6 itself before confirming UEF's exact version.

NEXT ACTION (updated 2026-10-03): Slice 0 — Foundation is in progress
under a strict one-file-per-authorization checkpoint discipline, now
further guarded by the Checkpoint Integrity Gate above. Four files
checkpointed and passed so far, in order: 60_Observability.js,
10_Config.js, 11_Schema.js, 12_Identity.js. Remaining in Slice 0 per
the Foundation Dependency Reconciliation's corrected file map:
13_EventDefinitions.js, 14_Versioning.js, 15_TruthEngine.js,
16_EventLog.js, 17_ReferenceBase.js, 19_Utils.js, 20/21 Router/Parser
(skeleton only). None of these are authorized yet — each still
requires its own explicit go-ahead, one file at a time, per Carson's
standing instruction not to proceed to the next file automatically.
*/
